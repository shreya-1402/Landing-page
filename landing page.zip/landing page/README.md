# The General Text
This is the landing page project readme

## The language used
-HTML
-CSS
-JS

## The funtionalities
-The Navigation
-The dynamic active
-The scrolling effect

## What did we learned:
In this project we converted the static web project into dynamic project

## How to use project:
1) open the browser
2) click on 'ctrl+O'
3) navigate to your index.html
4) click on it